import { commonAPI } from "./commonAPI"
import { base_URL } from "./serverURL"



export const uploadProduct= async(reqBody)=>{
   return await commonAPI('POST',`${base_URL}/products`,reqBody)
}


// export const getAllProducts = async()=>{
//   return await commonAPI('GET',`${base_URL}/products`,"")
// }



// export const deleteProducts = async(id)=>{
//    return await commonAPI('DELETE',`${base_URL}/products/${id}`,{})
// }
