import React from 'react'
import { Link } from 'react-router-dom'

function Search() {
  return (
    <div className='container-fluid'>
      <div className='row'>
      <div className="col-md-2 products-background" style={{height:'100vh'}}>
                <div className='mt-5 fs-5'>
                    <div style={{color:'white'}}>
                   <Link to='/' style={{color:'white'}}> <i class="fa-solid fa-house me-2"></i></Link>
                      Home
                    </div>
                    <div style={{color:'white'}}>
                        <Link  to='/products' style={{color:'white'}}><i class="fa-brands fa-dashcube me-2"></i></Link>
                       DashBoard</div>
                </div>
            </div>
        <div className='col-md-10 d-flex flex-column align-items-center mt-4 '>
          <div className='w-100  d-flex align-items-center justify-content-center '>
             <div className='w-25 px-2 d-flex align-items-center justify-content-center ' style={{border:'1px solid gray',borderRadius:'25px'}}>
                <input type="text" className='form-control' style={{border:'transparent'}} placeholder='search products' />
               <button style={{border:'transparent',backgroundColor:'transparent'}}> <i class="fa-solid fa-magnifying-glass fs-4" ></i></button>
             </div>
             <div></div>
          </div>
           <div className='mt-5 w-75'> 
              <table className='table table-bordered border-dark'>
                <thead>
                  <tr className='table-active text-center p-2'>
                    <th>Product Id</th>
                    <th>Product Name</th>
                    <th>Price</th>
                    
                  </tr>
                </thead>
                    
                <tbody>
                  <tr className='text-center p-2'>
                    <td></td>
                    <td>
                      <div className='d-flex align-items-center justify-content-between'>
                        <div></div>
                        <i class="fa-solid fa-trash-can fs-2 text-danger"></i>
                      </div>
                    </td>
                    <td></td>
                    
                 </tr>
                </tbody>
             </table>
            </div>
        </div>
      </div>
    </div>
  )
}

export default Search